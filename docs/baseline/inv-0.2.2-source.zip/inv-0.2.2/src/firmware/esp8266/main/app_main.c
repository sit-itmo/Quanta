/* SPDX-License-Identifier: MIT */
#include <stdio.h>
#include <string.h>
#include <FreeRTOS.h>
#include <task.h>
#include <esp_system.h>
#include "internal.h"
#include <math.h>

/* Локальный форматтер прошивки: newlib xtensa не поддерживает %llu и %g. */
static void fmt_u64(char *out, size_t cap, uint64_t v) {
    unsigned long hi = (unsigned long)(v / 1000000000ull);
    unsigned long lo = (unsigned long)(v % 1000000000ull);
    if (hi) snprintf(out, cap, "%lu%09lu", hi, lo);
    else snprintf(out, cap, "%lu", lo);
}

static void fmt_f64(char *out, size_t cap, double d) {
    double ip = 0.0;
    double fr = modf(d, &ip);
    unsigned long frac = (unsigned long)((fr < 0.0 ? -fr : fr) * 1000000.0 + 0.5);
    if (frac == 1000000ul) { ip += d < 0.0 ? -1.0 : 1.0; frac = 0; }
    snprintf(out, cap, "%s%lu.%06lu", d < 0.0 ? "-" : "",
             (unsigned long)(ip < 0.0 ? -ip : ip), frac);
}

static void fmt_value(char *out, size_t cap, const inv_value *v) {
    switch (v->type) {
    case INV_U64:  fmt_u64(out, cap, v->as.u64); break;
    case INV_F64:  fmt_f64(out, cap, v->as.f64); break;
    case INV_BOOL: inv_copy(out, cap, v->as.boolean ? "true" : "false"); break;
    default:       inv_safe_text(out, cap, v->as.string); break;
    }
}
static inv_read_ctx ctxs[INV_PROVIDER_COUNT];
static unsigned opened_mask;

static int ensure_open(const inv_provider_desc *p) {
    if (opened_mask & (1u << p->index)) return 1;
    memset(&ctxs[p->index], 0, sizeof(ctxs[p->index]));
    if (p->open && p->open(&ctxs[p->index]) != INV_OK) return 0;
    opened_mask |= 1u << p->index;
    return 1;
}

static void probe(const char *key) {
    const inv_metric_desc *m = inv_metric_find(key);
    inv_read_ctx *c;
    inv_instance in;
    inv_value v;
    uint64_t w = 0;
    uint32_t q = 0;
    char text[160];
    inv_status s;
    if (!m) { printf("%-24s %s\n", key, "NOT-IN-REGISTRY"); return; }
    if (!ensure_open(m->provider)) { printf("%-24s %s\n", key, "OPEN-FAILED"); return; }
    c = &ctxs[m->provider->index];
    if (m->provider->refresh) {
        s = m->provider->refresh(c);
        if (s != INV_OK) { printf("%-24s %s\n", key, inv_status_name(s)); return; }
    }
    memset(&in, 0, sizeof(in));
    in.metric = m;
    inv_copy(in.entity_key, sizeof(in.entity_key), "system");
    v.type = m->type; 
    s = m->read(c, &in, &v, &w, &q);
    if (s != INV_OK) { printf("%-24s %s\n", key, inv_status_name(s)); return; }
    fmt_value(text, sizeof(text), &v);
    printf("%-24s %s\n", key, text);
}

static const char *const keys[] = {
    "mcu.heap.free_bytes", "mcu.cpu.freq_mhz", "mcu.power.vdd_mv",
    "mcu.cores", "mcu.chip_id", "mcu.sdk_version",
    "os.uptime", "os.hostname", "os.name"
};

void app_main(void) {
    size_t i, n = 0;
    printf("inv esp8266: provider smoke\n");
    inv_registry(&n);
    printf("registry metrics: %u\n", (unsigned)n);
    while (1) {
        printf("-- heap=%u --\n", (unsigned)esp_get_free_heap_size());
        for (i = 0; i < sizeof(keys) / sizeof(keys[0]); i++) probe(keys[i]);
        vTaskDelay(2000 / portTICK_PERIOD_MS);
    }
}