// providers/cpuid.c
#include "internal.h"
#include "hal_cpuid.h"

static inv_status cpuid_open(inv_read_ctx *c) {
    cpuid_data *p = (cpuid_data *)calloc(1, sizeof(*p));
    if (!p) return INV_NO_MEMORY;
    c->data = p;
    return hal_cpuid_probe(p, c); /* свойство ONCE: пробуем один раз при open */
}
static inv_status cpuid_discover(inv_read_ctx *c, inv_discovery_sink *s) {
    return inv_discover_single(c, &inv_cpuid_provider, s);
}
static void cpuid_close(inv_read_ctx *c) {
    hal_cpuid_cleanup((cpuid_data *)c->data);
    free(c->data);
    c->data = NULL;
}

inv_status inv_cpuid_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    cpuid_data *p = (cpuid_data *)c->data;
    const char *a = in->metric->arg;
    (void)w; (void)q;
    if (p->status != INV_OK) return p->status;
    if (!strcmp(a, "vendor")) return inv_copy(v->as.string, sizeof(v->as.string), p->vendor) ? INV_OK : INV_LIMIT;
    if (!strcmp(a, "brand")) {
        if (!p->brand[0]) return INV_NO_DATA;
        return inv_copy(v->as.string, sizeof(v->as.string), p->brand) ? INV_OK : INV_LIMIT;
    }
    if (!strcmp(a, "cpuid_reference")) { v->as.u64 = p->ref; return INV_OK; }
    if (!strcmp(a, "vmx")) v->as.boolean = !!(p->ecx1 & (1u << 5));
    else if (!strcmp(a, "svm")) v->as.boolean = !!(p->ecxext & (1u << 2));
    else if (!strcmp(a, "sse2")) v->as.boolean = !!(p->edx1 & (1u << 26));
    else if (!strcmp(a, "avx")) v->as.boolean = !!(p->ecx1 & (1u << 28));
    else if (!strcmp(a, "avx2")) v->as.boolean = !!(p->ebx7 & (1u << 5));
    else if (!strcmp(a, "hypervisor")) v->as.boolean = !!(p->ecx1 & (1u << 31));
    else return INV_UNSUPPORTED;
    return INV_OK;
}

const inv_provider_desc inv_cpuid_provider = {
    6, "x86.cpuid", "Direct CPUID on a pinned, affinity-allowed reference CPU",
    cpuid_open, cpuid_discover, NULL, cpuid_close
};