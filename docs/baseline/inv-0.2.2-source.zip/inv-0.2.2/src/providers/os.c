#include "internal.h"
#include "os.h"

static inv_status os_open(inv_read_ctx *c) {
    c->data = calloc(1, sizeof(os_data));
    return c->data ? INV_OK : INV_NO_MEMORY;
}
static inv_status os_discover(inv_read_ctx *c, inv_discovery_sink *s) {
    return inv_discover_single(c, &inv_os_provider, s);
}
static inv_status os_refresh(inv_read_ctx *c) {
    return hal_os_refresh((os_data *)c->data, c);
}
static void os_close(inv_read_ctx *c) {
    hal_os_cleanup((os_data *)c->data);
    free(c->data);
    c->data = NULL;
}

inv_status inv_os_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    const os_data *d = (const os_data *)c->data;
    const char *a = in->metric->arg;
    (void)w; (void)q;
    if (!strcmp(a, "hostname")) { if (d->hostname_status != INV_OK) return d->hostname_status; return inv_copy(v->as.string, sizeof(v->as.string), d->hostname) ? INV_OK : INV_LIMIT; }
    if (!strcmp(a, "kernel")) { if (d->kernel_status != INV_OK) return d->kernel_status; return inv_copy(v->as.string, sizeof(v->as.string), d->kernel) ? INV_OK : INV_LIMIT; }
    if (!strcmp(a, "name")) { if (!d->name[0]) return INV_UNSUPPORTED; return inv_copy(v->as.string, sizeof(v->as.string), d->name) ? INV_OK : INV_LIMIT; }
    if (!strcmp(a, "version")) { if (!d->version[0]) return INV_UNSUPPORTED; return inv_copy(v->as.string, sizeof(v->as.string), d->version) ? INV_OK : INV_LIMIT; }
    if (!strcmp(a, "uptime")) { if (d->uptime_status != INV_OK) return d->uptime_status; v->as.f64 = d->uptime; return INV_OK; }
    if (!strcmp(a, "load_1m")) { if (d->load_status != INV_OK) return d->load_status; v->as.f64 = d->load[0]; return INV_OK; }
    if (!strcmp(a, "load_5m")) { if (d->load_status != INV_OK) return d->load_status; v->as.f64 = d->load[1]; return INV_OK; }
    if (!strcmp(a, "load_15m")) { if (d->load_status != INV_OK) return d->load_status; v->as.f64 = d->load[2]; return INV_OK; }
    return INV_UNSUPPORTED;
}

const inv_provider_desc inv_os_provider = {
    0, "os",
    "System identity and load: gethostname/uname/proc on Linux, WinAPI on Windows",
    os_open, os_discover, os_refresh, os_close
};