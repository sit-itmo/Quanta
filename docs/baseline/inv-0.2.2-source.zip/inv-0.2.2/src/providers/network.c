// providers/network.c
#include "internal.h"
#include "network.h"

static inv_status net_open(inv_read_ctx *c) {
    c->data = calloc(1, sizeof(net_data));
    return c->data ? INV_OK : INV_NO_MEMORY;
}

static inv_status net_refresh(inv_read_ctx *c) {
    return hal_network_refresh((net_data *)c->data, c);
}

static void net_close(inv_read_ctx *c) {
    hal_network_cleanup((net_data *)c->data);
    free(c->data);
    c->data = NULL;
}

static inv_status net_discover(inv_read_ctx *c, inv_discovery_sink *sink) {
    net_data *d = (net_data *)c->data;
    const inv_metric_desc *const *r;
    size_t n, i, j;
    inv_status s = hal_network_refresh(d, c);
    if (s != INV_OK) return s;
    r = inv_registry(&n);
    for (i = 0; i < d->count; i++) {
        const net_row *row = &d->rows[i];
        for (j = 0; j < n; j++) {
            inv_instance in;
            inv_status st;
            if (r[j]->provider != &inv_network_provider || !inv_metric_wanted(c, r[j])) continue;
            memset(&in, 0, sizeof(in));
            in.metric = r[j];
            inv_copy(in.entity_key, sizeof(in.entity_key), row->name);
            if (!inv_label_set(in.labels, &in.label_count, "ifname", row->name)) return INV_LIMIT;
            if (row->device[0] && !inv_label_set(in.labels, &in.label_count, "device", row->device)) return INV_LIMIT;
            st = sink->emit(sink->context, &in);
            if (st != INV_OK) return st;
        }
    }
    return INV_OK;
}

static const net_row *find_row(const net_data *d, const char *name) {
    size_t i;
    for (i = 0; i < d->count; i++) if (!strcmp(d->rows[i].name, name)) return &d->rows[i];
    return NULL;
}

inv_status inv_network_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    const net_data *d = (const net_data *)c->data;
    const net_row *r = find_row(d, in->entity_key);
    const char *a = in->metric->arg;
    (void)w; (void)q;
    if (!r) return INV_GONE;
    if (!strcmp(a, "rx_bytes")) { v->as.u64 = r->rx_bytes; return INV_OK; }
    if (!strcmp(a, "rx_packets")) { v->as.u64 = r->rx_packets; return INV_OK; }
    if (!strcmp(a, "rx_errors")) { v->as.u64 = r->rx_errors; return INV_OK; }
    if (!strcmp(a, "rx_dropped")) { v->as.u64 = r->rx_dropped; return INV_OK; }
    if (!strcmp(a, "tx_bytes")) { v->as.u64 = r->tx_bytes; return INV_OK; }
    if (!strcmp(a, "tx_packets")) { v->as.u64 = r->tx_packets; return INV_OK; }
    if (!strcmp(a, "tx_errors")) { v->as.u64 = r->tx_errors; return INV_OK; }
    if (!strcmp(a, "tx_dropped")) { v->as.u64 = r->tx_dropped; return INV_OK; }
    if (!strcmp(a, "speed")) { v->as.u64 = r->speed_mbit; return r->speed_status; }
    if (!strcmp(a, "up")) { v->as.u64 = (uint64_t)r->up; return r->up_status; }
    return INV_UNSUPPORTED;
}

const inv_provider_desc inv_network_provider = {
    4, "network",
    "Per-interface counters: /proc/net/dev + sysfs speed/operstate on Linux, GetIfTable2 on Windows",
    net_open, net_discover, net_refresh, net_close
};