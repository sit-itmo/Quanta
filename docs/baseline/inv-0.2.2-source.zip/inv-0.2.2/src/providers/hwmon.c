// providers/hwmon.c
#include "internal.h"
#include "hwmon.h"
#include "windows_math.h"

static inv_status hw_open(inv_read_ctx *c) {
    hwmon_data *d = (hwmon_data *)calloc(1, sizeof(*d));
    if (!d) return INV_NO_MEMORY;
    c->data = d;
    return hal_hwmon_open(d, c);
}

static inv_status hw_refresh(inv_read_ctx *c) {
    return hal_hwmon_refresh((hwmon_data *)c->data, c);
}

static void hw_close(inv_read_ctx *c) {
    hwmon_data *d = (hwmon_data *)c->data;
    if (d) {
        hal_hwmon_cleanup(d);
        free(d);
        c->data = NULL;
    }
}

static int kind_for_arg(const char *arg, hwmon_kind *kind) {
    if (!strcmp(arg, "temp")) { *kind = HWMON_TEMP; return 1; }
    if (!strcmp(arg, "fan")) { *kind = HWMON_FAN; return 1; }
    return 0;
}

static inv_status hw_discover(inv_read_ctx *c, inv_discovery_sink *sink) {
    hwmon_data *d = (hwmon_data *)c->data;
    const inv_metric_desc *const *r;
    size_t n, i, j;
    inv_status s = hal_hwmon_discover(d, c);
    if (s != INV_OK) return s;
    r = inv_registry(&n);
    for (i = 0; i < d->count; i++) {
        const hwmon_channel *ch = &d->ch[i];
        for (j = 0; j < n; j++) {
            hwmon_kind want;
            inv_instance in;
            inv_status st;
            if (r[j]->provider != &inv_hwmon_provider || !inv_metric_wanted(c, r[j])) continue;
            if (!kind_for_arg(r[j]->arg, &want) || want != ch->kind) continue;
            memset(&in, 0, sizeof(in));
            in.metric = r[j];
            in.min_poll_ns = ch->min_poll_ns;
            inv_copy(in.entity_key, sizeof(in.entity_key), ch->entity_key);
            inv_copy(in.resource, sizeof(in.resource), ch->resource);
            if (!inv_label_set(in.labels, &in.label_count, "chip", ch->chip) ||
                !inv_label_set(in.labels, &in.label_count, "channel", ch->channel) ||
                !inv_label_set(in.labels, &in.label_count, "label", ch->label) ||
                !inv_label_set(in.labels, &in.label_count, "device", ch->device)) return INV_LIMIT;
            st = sink->emit(sink->context, &in);
            if (st != INV_OK) return st;
        }
    }
    return INV_OK;
}

static const hwmon_channel *find_channel(const hwmon_data *d, const char *entity_key) {
    size_t i;
    for (i = 0; i < d->count; i++) if (!strcmp(d->ch[i].entity_key, entity_key)) return &d->ch[i];
    return NULL;
}

inv_status inv_hwmon_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    hwmon_data *d = (hwmon_data *)c->data;
    const hwmon_channel *ch = find_channel(d, in->entity_key);
    double raw = 0;
    inv_status fault = INV_OK, s;
    (void)w; (void)q;
    if (!ch) return INV_GONE;
    s = hal_hwmon_read(d, ch, &raw, &fault);
    if (s != INV_OK) return s;
    if (fault != INV_OK) return fault;
    switch (ch->unit) {
    case HWMON_MILLI_C: v->as.f64 = raw / 1000.0; return INV_OK;
    case HWMON_KELVIN:  return inv_win_kelvin_celsius(raw, &v->as.f64);
    case HWMON_RPM:
        if (raw < 0) return INV_INVALID_DATA;
        v->as.u64 = (uint64_t)raw;
        return INV_OK;
    }
    return INV_UNSUPPORTED;
}

const inv_provider_desc inv_hwmon_provider = {
    5, "sensors",
    "Read-only temperature/fan channels: sysfs hwmon on Linux, PDH thermal zones on Windows; fault-aware",
    hw_open, hw_discover, hw_refresh, hw_close
};