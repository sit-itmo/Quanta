/* SPDX-License-Identifier: MIT */
#include "internal.h"
#include "mcu.h"

static inv_status mcu_open(inv_read_ctx *c) {
    c->data = calloc(1, sizeof(mcu_data));
    return c->data ? INV_OK : INV_NO_MEMORY;
}
static inv_status mcu_discover(inv_read_ctx *c, inv_discovery_sink *s) {
    return inv_discover_single(c, &inv_mcu_provider, s);
}
static inv_status mcu_refresh(inv_read_ctx *c) {
    return hal_mcu_refresh((mcu_data *)c->data, c);
}
static void mcu_close(inv_read_ctx *c) {
    hal_mcu_cleanup((mcu_data *)c->data);
    free(c->data);
    c->data = NULL;
}

inv_status inv_mcu_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    mcu_data *d = (mcu_data *)c->data;
    const char *a = in->metric->arg;
    (void)w; (void)q;
    if (d->status != INV_OK) return d->status;
    if (!strcmp(a, "heap_free")) { v->as.u64 = d->heap_free; return INV_OK; }
    if (!strcmp(a, "heap_min_free")) { v->as.u64 = d->heap_min_free; return INV_OK; }
    if (!strcmp(a, "freq_mhz")) { v->as.u64 = d->freq_mhz; return INV_OK; }
    if (!strcmp(a, "cores")) { v->as.u64 = d->cores; return INV_OK; }
    if (!strcmp(a, "revision")) { v->as.u64 = d->revision; return INV_OK; }
    if (!strcmp(a, "chip_id")) { v->as.u64 = d->chip_id; return d->chip_id_status; }
    if (!strcmp(a, "flash_embedded")) { v->as.boolean = !!d->emb_flash; return INV_OK; }
    if (!strcmp(a, "vdd_mv")) { v->as.u64 = d->vdd_mv; return d->vdd_status; }
    if (!strcmp(a, "sdk_version")) return inv_copy(v->as.string, sizeof(v->as.string), d->sdk_version) ? INV_OK : INV_LIMIT;
    return INV_UNSUPPORTED;
}

const inv_provider_desc inv_mcu_provider = {
    9, "mcu",
    "ESP8266 chip identity, heap, clock and supply voltage from SDK system API",
    mcu_open, mcu_discover, mcu_refresh, mcu_close
};