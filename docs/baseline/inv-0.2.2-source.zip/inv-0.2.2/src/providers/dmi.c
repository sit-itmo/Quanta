/* SPDX-License-Identifier: MIT */
// providers/dmi.c
#include "internal.h"
#include "dmi.h"

static inv_status copy_field(const inv_dmi_string *s, inv_value *v) {
    if (s->status != INV_OK) return s->status;
    return inv_copy(v->as.string, sizeof(v->as.string), s->text) ? INV_OK : INV_LIMIT;
}

static inv_status dmi_open(inv_read_ctx *c) {
    c->data = calloc(1, sizeof(dmi_data));
    return c->data ? INV_OK : INV_NO_MEMORY;
}

static inv_status dmi_discover(inv_read_ctx *c, inv_discovery_sink *s) {
    return inv_discover_single(c, &inv_dmi_provider, s);
}

static inv_status dmi_refresh(inv_read_ctx *c) {
    return hal_dmi_refresh((dmi_data *)c->data, c);
}

static void dmi_close(inv_read_ctx *c) {
    free(c->data);
    c->data = NULL;
}

inv_status inv_dmi_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    dmi_data *p = (dmi_data *)c->data;
    const char *a = in->metric->arg;
    static const char *const fields[] = {
        "bios_vendor", "bios_version", "bios_date",
        "board_vendor", "board_name", "board_serial",
        "system_vendor", "system_model", "system_serial"
    };
    size_t i;
    uint64_t handle;
    (void)w; (void)q;

    if (p->status != INV_OK) return p->status;

    for (i = 0; i < INV_ARRAY_SIZE(fields); i++)
        if (!strcmp(a, fields[i]))
            return copy_field(&p->table.fields[i], v);

    if (!strcmp(a, "system_uuid"))
        return copy_field(&p->table.uuid, v);

    if (strncmp(a, "dimm_", 5) || !inv_parse_u64(in->resource, &handle))
        return INV_UNSUPPORTED;

    for (i = 0; i < p->table.dimm_count; i++)
        if (p->table.dimms[i].handle == handle) {
            inv_dmi_dimm *d = &p->table.dimms[i];
            if (!strcmp(a, "dimm_size")) { v->as.u64 = d->size_bytes; return d->size_status; }
            if (!strcmp(a, "dimm_speed")) { v->as.u64 = d->speed_mt_s; return d->speed_status; }
            if (!strcmp(a, "dimm_vendor")) return copy_field(&d->vendor, v);
            if (!strcmp(a, "dimm_serial")) return copy_field(&d->serial, v);
            if (!strcmp(a, "dimm_part")) return copy_field(&d->part, v);
            return INV_UNSUPPORTED;
        }
    return INV_GONE;
}

const inv_provider_desc inv_dmi_provider = {
    3, "dmi", "Read-only DMI/SMBIOS firmware data (sysfs dmi-id / RSMB table); never elevates privileges",
    dmi_open, dmi_discover, dmi_refresh, dmi_close
};