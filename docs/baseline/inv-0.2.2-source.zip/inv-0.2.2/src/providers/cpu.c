/* SPDX-License-Identifier: MIT */
#include "internal.h"
#include <ctype.h>
#include "cpu.h"

inv_status inv_cpu_fraction(const uint64_t p[8], const uint64_t n[8], double *out) {
    uint64_t total = 0, idle = 0;
    size_t i;
    for (i = 0; i < 8; i++) {
        uint64_t diff;
        if (n[i] < p[i]) return INV_WARMUP;
        diff = n[i] - p[i];
        if (UINT64_MAX - total < diff) return INV_INVALID_DATA;
        total += diff;
        if (i == CPU_IDLE || i == CPU_IOWAIT) {
            if (UINT64_MAX - idle < diff) return INV_INVALID_DATA;
            idle += diff;
        }
    }
    if (!total) return INV_WARMUP;
    *out = (double)(total - idle) / (double)total;
    return INV_OK;
}

static inv_status cpu_open(inv_read_ctx *c) {
    c->data = calloc(1, sizeof(cpu_data));
    return c->data ? INV_OK : INV_NO_MEMORY;
}

/* Обёртка: адаптирует сигнатуру HAL к сигнатуре provider */
static inv_status cpu_refresh_wrapper(inv_read_ctx *c) {
    cpu_data *d = (cpu_data *)c->data;
    return hal_cpu_refresh(d, c);
}

static inv_status cpu_discover(inv_read_ctx *c, inv_discovery_sink *sink) {
    cpu_data *d = (cpu_data *)c->data;
    size_t i, j, n;
    inv_status s = cpu_refresh_wrapper(c);
    const inv_metric_desc *const *r = inv_registry(&n);
    if (s != INV_OK) return s;
    for (i = 0; i < d->count; i++)
        for (j = 0; j < n; j++)
            if (r[j]->provider == &inv_cpu_provider && inv_metric_wanted(c, r[j])) {
                int core = !strncmp(r[j]->key, "cpu.core.", 9);
                inv_instance in;
                if (core == !strcmp(d->rows[i].name, "cpu")) continue;
                memset(&in, 0, sizeof(in));
                in.metric = r[j];
                inv_copy(in.resource, sizeof(in.resource), d->rows[i].name);
                inv_copy(in.entity_key, sizeof(in.entity_key), d->rows[i].name);
                if (core) inv_label_set(in.labels, &in.label_count, "cpu", d->rows[i].name + 3);
                s = sink->emit(sink->context, &in);
                if (s != INV_OK) return s;
            }
    return INV_OK;
}

static void cpu_close(inv_read_ctx *c) {
    cpu_data *d = (cpu_data *)c->data;
    if (d) {
        hal_cpu_cleanup(d);
        free(d);
        c->data = NULL;
    }
}

inv_status inv_cpu_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    cpu_data *d = (cpu_data *)c->data;
    cpu_row *r = NULL;
    size_t i, k;
    const char *a = in->metric->arg;
    (void)q;
    for (i = 0; i < d->count; i++)
        if (!strcmp(in->resource, d->rows[i].name)) { r = &d->rows[i]; break; }
    if (!r) return INV_GONE;
    if (!strcmp(a, "utilization")) {
        inv_status s = in->reader_state[8] ? inv_cpu_fraction(in->reader_state, r->t, &v->as.f64) : INV_WARMUP;
        if (in->reader_state[8] && d->time_ns > in->reader_state[9])
            *w = d->time_ns - in->reader_state[9];
        memcpy(in->reader_state, r->t, 8 * sizeof(uint64_t));
        in->reader_state[8] = 1;
        in->reader_state[9] = d->time_ns;
        return s;
    }
    if (!strcmp(a, "idle")) { v->as.u64 = r->t[3]; return INV_OK; }
    if (!strcmp(a, "total")) {
        uint64_t sum = 0;
        for (k = 0; k < 8; k++) {
            if (UINT64_MAX - sum < r->t[k]) return INV_INVALID_DATA;
            sum += r->t[k];
        }
        v->as.u64 = sum;
        return INV_OK;
    }
    return INV_UNSUPPORTED;
}

const inv_provider_desc inv_cpu_provider = {
    2, "cpu", "CPU utilization and ticks", cpu_open, cpu_discover, cpu_refresh_wrapper, cpu_close
};