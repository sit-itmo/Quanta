#include "internal.h"
#include "process.h"

static inv_status proc_open(inv_read_ctx *c) {
    c->data = calloc(1, sizeof(process_data));
    return c->data ? INV_OK : INV_NO_MEMORY;
}
static inv_status proc_discover(inv_read_ctx *c, inv_discovery_sink *s) {
    return inv_discover_single(c, &inv_process_provider, s);
}
static inv_status proc_refresh(inv_read_ctx *c) {
    return hal_process_refresh((process_data *)c->data, c);
}
static void proc_close(inv_read_ctx *c) {
    hal_process_cleanup((process_data *)c->data);
    free(c->data);
    c->data = NULL;
}

inv_status inv_process_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    const process_data *d = (const process_data *)c->data;
    const char *a = in->metric->arg;
    (void)w; (void)q;
    if (!strcmp(a, "count")) {
        if (d->status != INV_OK) return d->status;
        v->as.u64 = d->count;
        return INV_OK;
    }
    return INV_UNSUPPORTED;
}

const inv_provider_desc inv_process_provider = {
    8, "process",
    "System process count: /proc enumeration on Linux, GetPerformanceInfo on Windows",
    proc_open, proc_discover, proc_refresh, proc_close
};