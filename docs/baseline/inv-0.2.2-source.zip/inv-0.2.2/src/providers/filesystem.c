#include "internal.h"
#include "filesystem.h"

static inv_status fs_open(inv_read_ctx *c) {
    c->data = calloc(1, sizeof(fs_data));
    return c->data ? INV_OK : INV_NO_MEMORY;
}
static inv_status fs_discover(inv_read_ctx *c, inv_discovery_sink *s) {
    return inv_discover_single(c, &inv_filesystem_provider, s);
}
static inv_status fs_refresh(inv_read_ctx *c) {
    return hal_fs_refresh((fs_data *)c->data, c);
}
static void fs_close(inv_read_ctx *c) {
    hal_fs_cleanup((fs_data *)c->data);
    free(c->data);
    c->data = NULL;
}

inv_status inv_filesystem_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    fs_data *d = (fs_data *)c->data;
    const char *a = in->metric->arg;
    (void)w; (void)q;
    if (d->status != INV_OK) return d->status;
    if (!strcmp(a, "total_bytes"))          v->as.u64 = d->total;
    else if (!strcmp(a, "available_bytes")) v->as.u64 = d->available;
    else if (!strcmp(a, "used_bytes"))      v->as.u64 = d->total - d->free;
    else if (!strcmp(a, "utilization")) {
        if (!d->total) return INV_NO_DATA;
        v->as.f64 = (double)(d->total - d->free) / (double)d->total;
    } else return INV_UNSUPPORTED;
    return INV_OK;
}

const inv_provider_desc inv_filesystem_provider = {
    7, "filesystem",
    "Root filesystem space: statvfs('/') on Linux, GetDiskFreeSpaceExW on the Windows install volume",
    fs_open, fs_discover, fs_refresh, fs_close
};