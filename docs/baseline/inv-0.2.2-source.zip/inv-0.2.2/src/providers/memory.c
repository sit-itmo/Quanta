// providers/memory.c
#include "internal.h"
#include "memory.h"
#include "windows_math.h"

static inv_status mem_open(inv_read_ctx *c) {
    c->data = calloc(1, sizeof(mem_data));
    return c->data ? INV_OK : INV_NO_MEMORY;
}
static inv_status mem_discover(inv_read_ctx *c, inv_discovery_sink *s) {
    return inv_discover_single(c, &inv_memory_provider, s);
}
static inv_status mem_refresh(inv_read_ctx *c) {
    return hal_memory_refresh((mem_data *)c->data, c);
}
static void mem_close(inv_read_ctx *c) {
    hal_memory_cleanup((mem_data *)c->data);
    free(c->data);
    c->data = NULL;
}

inv_status inv_memory_read(inv_read_ctx *c, inv_instance *in, inv_value *v, uint64_t *w, uint32_t *q) {
    const mem_data *d = (const mem_data *)c->data;
    const char *a = in->metric->arg;
    (void)w; (void)q;

    /* Windows-only семейство: свой источник и свой статус. */
    if (!strcmp(a, "process_count")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->process_count; return INV_OK; }
    if (!strcmp(a, "thread_count")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->thread_count; return INV_OK; }
    if (!strcmp(a, "handle_count")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->handle_count; return INV_OK; }
    if (!strcmp(a, "commit_used")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->commit_used; return INV_OK; }
    if (!strcmp(a, "commit_limit")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->commit_limit; return INV_OK; }
    if (!strcmp(a, "commit_peak")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->commit_peak; return INV_OK; }
    if (!strcmp(a, "cache")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->cache; return INV_OK; }
    if (!strcmp(a, "kernel_paged")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->kernel_paged; return INV_OK; }
    if (!strcmp(a, "kernel_nonpaged")) { if (d->performance_status != INV_OK) return d->performance_status; v->as.u64 = d->kernel_nonpaged; return INV_OK; }

    /* Физическая память и swap: общий путь обеих платформ. */
    if (d->memory_status != INV_OK) return d->memory_status;
    if (!strcmp(a, "total")) { if (!(d->found & 1)) return INV_NO_DATA; v->as.u64 = d->total; return INV_OK; }
    if (!strcmp(a, "available")) {
        if (!(d->found & 2)) return INV_NO_DATA;
        v->as.u64 = d->available;
        *q |= INV_QUALITY_ESTIMATED;
        return INV_OK;
    }
    if (!strcmp(a, "free")) { if (!(d->found & 4)) return INV_NO_DATA; v->as.u64 = d->free; return INV_OK; }
    if (!strcmp(a, "used") || !strcmp(a, "utilization")) {
        uint64_t used;
        double fraction;
        inv_status st;
        if ((d->found & 3) != 3) return INV_NO_DATA;
        st = inv_win_memory_used(d->total, d->available, &used, &fraction);
        if (st != INV_OK) return st;
        if (!strcmp(a, "used")) v->as.u64 = used;
        else v->as.f64 = fraction;
        *q |= INV_QUALITY_ESTIMATED;
        return INV_OK;
    }
    if (!strcmp(a, "swap_total")) { if (!(d->found & 8)) return INV_NO_DATA; v->as.u64 = d->swap_total; return INV_OK; }
    if (!strcmp(a, "swap_used")) { if ((d->found & 24) != 24) return INV_NO_DATA; v->as.u64 = d->swap_total - d->swap_free; return INV_OK; }
    return INV_UNSUPPORTED;
}

const inv_provider_desc inv_memory_provider = {
    1, "memory",
    "One /proc/meminfo snapshot; Windows: GlobalMemoryStatusEx + GetPerformanceInfo",
    mem_open, mem_discover, mem_refresh, mem_close
};