/* SPDX-License-Identifier: MIT */
#include "internal.h"
#include "os.h"
#include <esp_system.h>
#include <esp_wifi.h>

inv_status hal_os_refresh(os_data *out, void *ctx) {
    (void)ctx;
    memset(out, 0, sizeof(*out));

    {
        uint8_t mac[6];
        if (esp_wifi_get_mac(ESP_IF_WIFI_STA, mac) == ESP_OK)
            snprintf(out->hostname, sizeof(out->hostname), "esp8266-%02x%02x%02x",
                     mac[3], mac[4], mac[5]);
        else
            inv_copy(out->hostname, sizeof(out->hostname), "esp8266");
        out->hostname_status = INV_OK;
    }

    inv_copy(out->kernel, sizeof(out->kernel), esp_get_idf_version());
    out->kernel_status = INV_OK;

    inv_copy(out->name, sizeof(out->name), "ESP8266 RTOS SDK");
    inv_copy(out->version, sizeof(out->version), esp_get_idf_version());

    out->uptime = (double)inv_now_ns() / (double)INV_NS_S;
    out->uptime_status = INV_OK;

    out->load_status = INV_UNSUPPORTED; /* load average на MCU смысла не имеет */
    return INV_OK;
}

void hal_os_cleanup(os_data *d) { (void)d; }