/* SPDX-License-Identifier: MIT */
#include "internal.h"
#include "mcu.h"
#include <esp_system.h>
#include <esp_wifi.h>
#include <FreeRTOS.h>

/* Эквивалент legacy system_get_chip_id: 24-bit id из фьюзованного STA-MAC. */
static int mac_chip_id(uint32_t *id) {
    uint8_t mac[6];
    if (esp_wifi_get_mac(ESP_IF_WIFI_STA, mac) != ESP_OK) return 0;
    *id = ((uint32_t)mac[3] << 16) | ((uint32_t)mac[4] << 8) | mac[5];
    return 1;
}

inv_status hal_mcu_refresh(mcu_data *out, void *ctx) {
    esp_chip_info_t info;
    uint32_t id = 0;
    (void)ctx;
    memset(out, 0, sizeof(*out));
    out->heap_free = esp_get_free_heap_size();
    out->heap_min_free = esp_get_minimum_free_heap_size();
    /* Сконфигурированная частота ядра; runtime-переключение без getter'а не видно. */
    out->freq_mhz = (uint64_t)(configCPU_CLOCK_HZ / 1000000);
    esp_chip_info(&info);
    out->cores = info.cores;
    out->revision = info.revision;
    out->emb_flash = (info.features & CHIP_FEATURE_EMB_FLASH) ? 1 : 0;
    if (mac_chip_id(&id)) { out->chip_id = id; out->chip_id_status = INV_OK; }
    else out->chip_id_status = INV_NO_DATA;
    inv_copy(out->sdk_version, sizeof(out->sdk_version), esp_get_idf_version());
    out->vdd_mv = esp_wifi_get_vdd33();
    out->vdd_status = (out->vdd_mv && out->vdd_mv != 65535) ? INV_OK : INV_NO_DATA;
    out->status = INV_OK;
    return INV_OK;
}

void hal_mcu_cleanup(mcu_data *d) { (void)d; }