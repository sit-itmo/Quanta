// hal/include/hwmon.h
#ifndef HAL_HWMON_H
#define HAL_HWMON_H

#include "inv/inv.h"

typedef enum hwmon_kind { HWMON_TEMP, HWMON_FAN } hwmon_kind;
typedef enum hwmon_unit { HWMON_MILLI_C, HWMON_KELVIN, HWMON_RPM } hwmon_unit;

typedef struct hwmon_channel {
    hwmon_kind kind;
    hwmon_unit unit;
    char chip[INV_TEXT_CAP];
    char channel[48];
    char label[INV_TEXT_CAP];
    char device[INV_PATH_CAP];
    char entity_key[INV_ID_CAP];
    char resource[INV_PATH_CAP];
    uint64_t min_poll_ns;
} hwmon_channel;

typedef struct hwmon_data {
    hwmon_channel *ch;
    size_t count, cap;
    inv_status status;
    void *hal_private;
} hwmon_data;

inv_status hal_hwmon_open(hwmon_data *out, void *ctx);
inv_status hal_hwmon_discover(hwmon_data *out, void *ctx);
inv_status hal_hwmon_refresh(hwmon_data *out, void *ctx);
inv_status hal_hwmon_read(const hwmon_data *d, const hwmon_channel *ch,
                          double *raw, inv_status *fault);
void hal_hwmon_cleanup(hwmon_data *d);

#endif