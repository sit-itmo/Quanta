// hal/include/network.h
#ifndef HAL_NETWORK_H
#define HAL_NETWORK_H

#include "inv/inv.h"

/* Сырой снапшот по интерфейсам.
 * Linux: /sys/class/net + /proc/net/dev + sysfs speed/operstate.
 * Windows: один GetIfTable2. */
typedef struct net_row {
    char name[INV_TEXT_CAP];      /* ifname / Alias */
    char device[INV_TEXT_CAP];    /* label device: Description на Windows */
    uint64_t rx_bytes, rx_packets, rx_errors, rx_dropped;
    uint64_t tx_bytes, tx_packets, tx_errors, tx_dropped;
    uint64_t speed_mbit;
    int up;
    inv_status speed_status, up_status;
} net_row;

typedef struct net_data {
    net_row *rows;
    size_t count, cap;
    inv_status status;
} net_data;

inv_status hal_network_refresh(net_data *out, void *ctx);
void hal_network_cleanup(net_data *d);

#endif