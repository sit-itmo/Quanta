// hal/include/cpu.h
#ifndef HAL_CPU_H
#define HAL_CPU_H

#include <stdint.h>
#include <stddef.h>
#include "inv/inv.h" 


typedef enum inv_proc_state {
    CPU_USER, CPU_NICE, CPU_SYSTEM, CPU_IDLE, CPU_IOWAIT,
    CPU_IRQ, CPU_SOFTIRQ, CPU_STEAL
} inv_proc_state;

typedef struct cpu_row {
    char name[24];       // "cpu", "cpu0", "cpu1"...
    uint64_t t[8];       // 0:user, 1:nice, 2:system, 3:idle, 4:iowait, 5:irq, 6:softirq, 7:steal
} cpu_row;

typedef struct cpu_data {
    cpu_row *rows;
    size_t count, cap;
    uint64_t time_ns;
    uint64_t tick_frequency_hz; // 100 для Linux, 10000000 для Windows
    void *hal_private;          // Скрытое состояние HAL и всякие доп метрики 
} cpu_data;

inv_status hal_cpu_refresh(cpu_data *out, void *ctx);
void hal_cpu_cleanup(cpu_data *d);

#endif