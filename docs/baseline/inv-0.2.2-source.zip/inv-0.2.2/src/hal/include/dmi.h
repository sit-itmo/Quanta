// hal/include/dmi.h
#ifndef HAL_DMI_H
#define HAL_DMI_H

#include "inv/inv.h"
#include "smbios.h"

typedef struct dmi_data {
    inv_smbios table;
    inv_status status;
} dmi_data;

inv_status hal_dmi_refresh(dmi_data *out, void *ctx);
void hal_dmi_cleanup(dmi_data *d);

#endif