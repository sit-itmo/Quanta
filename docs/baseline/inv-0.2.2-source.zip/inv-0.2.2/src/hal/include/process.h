#ifndef HAL_PROCESS_H
#define HAL_PROCESS_H
#include "inv/inv.h"

typedef struct process_data {
    uint64_t count;
    inv_status status;
} process_data;

inv_status hal_process_refresh(process_data *out, void *ctx);
void hal_process_cleanup(process_data *d);
#endif