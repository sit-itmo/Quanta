// hal/include/memory.h
#ifndef HAL_MEMORY_H
#define HAL_MEMORY_H
#include "inv/inv.h"

/* Сырой снапшот памяти.
 * Linux: один разбор /proc/meminfo (байты + маска found).
 * Windows: GlobalMemoryStatusEx (физическая) + GetPerformanceInfo
 * (системные commit/object-счётчики, уже в байтах). */
typedef struct mem_data {
    uint64_t total, available, free, swap_total, swap_free;
    unsigned found;

    uint64_t process_count, thread_count, handle_count;
    uint64_t commit_used, commit_limit, commit_peak;
    uint64_t cache, kernel_paged, kernel_nonpaged;

    inv_status memory_status, performance_status;
} mem_data;

inv_status hal_memory_refresh(mem_data *out, void *ctx);
void hal_memory_cleanup(mem_data *d);
#endif