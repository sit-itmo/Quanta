#ifndef HAL_OS_H
#define HAL_OS_H
#include "inv/inv.h"

typedef struct os_data {
    char hostname[INV_TEXT_CAP];
    char kernel[INV_TEXT_CAP];
    char name[INV_TEXT_CAP];      /* Windows-only */
    char version[INV_TEXT_CAP];   /* Windows-only */
    double uptime;
    double load[3];
    inv_status hostname_status, kernel_status, uptime_status, load_status;
} os_data;

inv_status hal_os_refresh(os_data *out, void *ctx);
void hal_os_cleanup(os_data *d);
#endif