// hal/include/cpuid.h
#ifndef HAL_CPUID_H
#define HAL_CPUID_H
#include "inv/inv.h"

/* CPUID с одного reference CPU.
 * ref: Linux — номер logical CPU; Windows — (group << 16) | processor_number. */
typedef struct cpuid_data {
    char vendor[16];
    char brand[64];
    unsigned ref;
    uint32_t ecx1, edx1, ebx7, ecxext;
    inv_status status;
} cpuid_data;

inv_status hal_cpuid_probe(cpuid_data *out, void *ctx);
void hal_cpuid_cleanup(cpuid_data *d);
#endif