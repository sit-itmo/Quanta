#ifndef HAL_MCU_H
#define HAL_MCU_H
#include "inv/inv.h"

/* Сырьё ESP8266: идентичность чипа, heap, частота, питание. */
typedef struct mcu_data {
    uint64_t heap_free, heap_min_free;
    uint64_t freq_mhz;
    uint64_t cores, revision, chip_id;
    int emb_flash;
    uint64_t vdd_mv;
    inv_status chip_id_status;   
    char sdk_version[INV_TEXT_CAP];
    inv_status vdd_status;
    inv_status status;
} mcu_data;


inv_status hal_mcu_refresh(mcu_data *out, void *ctx);
void hal_mcu_cleanup(mcu_data *d);
#endif