#ifndef HAL_FS_H
#define HAL_FS_H
#include "inv/inv.h"

typedef struct fs_data {
    uint64_t total, free, available;
    inv_status status;
} fs_data;

inv_status hal_fs_refresh(fs_data *out, void *ctx);
void hal_fs_cleanup(fs_data *d);
#endif