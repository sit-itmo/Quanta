// hal/linux/memory.c
#include "internal.h"
#include "memory.h"
#include <ctype.h>

inv_status inv_parse_meminfo(const char *text, inv_mem_data *d) {
    const char *p = text;
    d->total = d->available = d->free = d->swap_total = d->swap_free = 0;
    d->found = 0;
    while (*p) {
        const char *key = p, *ks = p;
        unsigned bit;
        uint64_t *slot, x;
        while (*ks && *ks != ':') ks++;
        if (!*ks) break;
        if ((size_t)(ks - key) == 8 && !memcmp(key, "MemTotal", 8)) { bit = 1; slot = &d->total; }
        else if ((size_t)(ks - key) == 12 && !memcmp(key, "MemAvailable", 12)) { bit = 2; slot = &d->available; }
        else if ((size_t)(ks - key) == 7 && !memcmp(key, "MemFree", 7)) { bit = 4; slot = &d->free; }
        else if ((size_t)(ks - key) == 9 && !memcmp(key, "SwapTotal", 9)) { bit = 8; slot = &d->swap_total; }
        else if ((size_t)(ks - key) == 8 && !memcmp(key, "SwapFree", 8)) { bit = 16; slot = &d->swap_free; }
        else { p = ks + 1; while (*p && *p != '\n') p++; if (*p) p++; continue; }
        if (d->found & bit) return INV_INVALID_DATA;
        p = ks + 1;
        while (*p == ' ' || *p == '\t') p++;
        x = 0;
        if (!isdigit((unsigned char)*p)) return INV_INVALID_DATA;
        while (isdigit((unsigned char)*p)) {
            if (x > (UINT64_MAX - (uint64_t)(*p - '0')) / 10) return INV_INVALID_DATA;
            x = x * 10 + (uint64_t)(*p - '0');
            p++;
        }
        while (*p == ' ' || *p == '\t') p++;
        if (p[0] != 'k' || p[1] != 'B') return INV_INVALID_DATA;
        if (x > UINT64_MAX / 1024) return INV_INVALID_DATA;
        *slot = x * 1024;
        d->found |= bit;
        while (*p && *p != '\n') p++;
        if (*p) p++;
    }
    if (!(d->found & 1)) return INV_NO_DATA;
    if ((d->found & 3) == 3 && d->available > d->total) return INV_INVALID_DATA;
    if ((d->found & 24) == 24 && d->swap_free > d->swap_total) return INV_INVALID_DATA;
    return INV_OK;

}

inv_status hal_memory_refresh(mem_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    inv_mem_data m;
    char p[INV_PATH_CAP], b[32768];
    inv_status s;
    out->performance_status = INV_UNSUPPORTED; /* нет GetPerformanceInfo на Linux */
    if (!inv_path(p, sizeof(p), c->paths.proc_root, "meminfo")) {
        out->memory_status = INV_LIMIT;
        return INV_LIMIT;
    }
    s = inv_read_text(p, b, sizeof(b));
    if (s != INV_OK) { out->memory_status = s; return s; }
    s = inv_parse_meminfo(b, &m);
    out->memory_status = s;
    if (s != INV_OK) return s; /* ошибка источника = групповой статус, как раньше */
    out->total = m.total;
    out->available = m.available;
    out->free = m.free;
    out->swap_total = m.swap_total;
    out->swap_free = m.swap_free;
    out->found = m.found;
    return INV_OK;
}

void hal_memory_cleanup(mem_data *d) { (void)d; }