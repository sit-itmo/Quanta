// hal/linux/cpu.c
#include "internal.h"
#include "cpu.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

inv_status hal_cpu_refresh(cpu_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    char path[1024];
    snprintf(path, sizeof(path), "%s/stat", c->paths.proc_root);
    
    FILE *f = inv_fopen_utf8(path, "r");
    if (!f) return INV_IO_ERROR;

    out->count = 0;
    out->tick_frequency_hz = 100; // USER_HZ в Linux обычно 100

    char line[1024];
    while (fgets(line, sizeof(line), f)) {
        if (!strncmp(line, "cpu", 3) && (isspace((unsigned char)line[3]) || isdigit((unsigned char)line[3]))) {
            cpu_row row;
            memset(&row, 0, sizeof(row));
            
            char *s = line, *e;
            size_t len = 0;
            while (s[len] && !isspace((unsigned char)s[len])) len++;
            if (len >= sizeof(row.name)) continue;
            memcpy(row.name, s, len);
            s += len;

            for (int k = 0; k < 8; k++) {
                while (isspace((unsigned char)*s)) s++;
                if (!*s || !isdigit((unsigned char)*s)) break;
                row.t[k] = strtoull(s, &e, 10);
                s = e;
            }

            if (out->count == out->cap) {
                size_t cap = out->cap ? out->cap * 2 : 64;
                cpu_row *r = realloc(out->rows, cap * sizeof(*r));
                if (!r) { fclose(f); return INV_NO_MEMORY; }
                out->rows = r;
                out->cap = cap;
            }
            out->rows[out->count++] = row;
        }
    }
    fclose(f);
    out->time_ns = inv_now_ns();
    return out->count > 0 ? INV_OK : INV_NO_DATA;
}

void hal_cpu_cleanup(cpu_data *d) {
    free(d->rows);
    d->rows = NULL;
    d->count = d->cap = 0;
}