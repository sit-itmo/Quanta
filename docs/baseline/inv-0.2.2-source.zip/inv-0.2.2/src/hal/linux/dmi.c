/* SPDX-License-Identifier: MIT */
// hal/linux/dmi.c
#include "internal.h"
#include "dmi.h"

inv_status hal_dmi_refresh(dmi_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    char rel[256], p[INV_PATH_CAP];
    inv_status s;
    size_t i;

    memset(&out->table, 0, sizeof(out->table));

    static const char *const fields[] = {
        "bios_vendor", "bios_version", "bios_date",
        "board_vendor", "board_name", "board_serial",
        "sys_vendor", "product_name", "product_serial"
    };
    static const int field_idx[] = {
        INV_BIOS_VENDOR, INV_BIOS_VERSION, INV_BIOS_DATE,
        INV_BOARD_VENDOR, INV_BOARD_MODEL, INV_BOARD_SERIAL,
        INV_SYSTEM_VENDOR, INV_SYSTEM_MODEL, INV_SYSTEM_SERIAL
    };

    for (i = 0; i < INV_ARRAY_SIZE(fields); i++) {
        snprintf(rel, sizeof(rel), "class/dmi/id/%s", fields[i]);
        if (!inv_path(p, sizeof(p), c->paths.sys_root, rel)) {
            out->table.fields[field_idx[i]].status = INV_LIMIT;
            continue;
        }
        s = inv_read_text(p, out->table.fields[field_idx[i]].text,
                          sizeof(out->table.fields[field_idx[i]].text));
        if (s != INV_OK) {
            out->table.fields[field_idx[i]].status = s;
            continue;
        }
        inv_trim(out->table.fields[field_idx[i]].text);
        out->table.fields[field_idx[i]].status =
            out->table.fields[field_idx[i]].text[0] ? INV_OK : INV_NO_DATA;
    }

    /* UUID */
    snprintf(rel, sizeof(rel), "class/dmi/id/product_uuid");
    if (inv_path(p, sizeof(p), c->paths.sys_root, rel)) {
        s = inv_read_text(p, out->table.uuid.text, sizeof(out->table.uuid.text));
        if (s == INV_OK) {
            inv_trim(out->table.uuid.text);
            out->table.uuid.status = out->table.uuid.text[0] ? INV_OK : INV_NO_DATA;
        } else {
            out->table.uuid.status = s;
        }
    } else {
        out->table.uuid.status = INV_LIMIT;
    }

    out->status = INV_OK;
    return INV_OK;
}

void hal_dmi_cleanup(dmi_data *d) {
    (void)d;
}