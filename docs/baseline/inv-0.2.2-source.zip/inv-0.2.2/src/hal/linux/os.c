// hal/linux/os.c
#include "internal.h"
#include "os.h"
#include <ctype.h>
#include <sys/utsname.h>
#include <unistd.h>

static int parse_proc_double(const char *s, double *out) {
    double int_part = 0, frac = 0, scale = 1;
    if (!isdigit((unsigned char)*s)) return 0;
    while (isdigit((unsigned char)*s)) { int_part = int_part * 10 + (double)(*s - '0'); s++; }
    if (*s == '.') {
        s++;
        while (isdigit((unsigned char)*s)) { frac = frac * 10 + (double)(*s - '0'); scale *= 10; s++; }
    }
    *out = int_part + frac / scale;
    return 1;
}
inv_status hal_os_refresh(os_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    struct utsname un;
    char p[INV_PATH_CAP], b[256];
    inv_status s;
    memset(out, 0, sizeof(*out));

    if (gethostname(out->hostname, sizeof(out->hostname)))
        out->hostname_status = inv_errno_status(errno);
    else
        out->hostname_status = INV_OK;

    if (uname(&un))
        out->kernel_status = inv_errno_status(errno);
    else {
        inv_copy(out->kernel, sizeof(out->kernel), un.release);
        out->kernel_status = INV_OK;
    }

    if (!inv_path(p, sizeof(p), c->paths.proc_root, "uptime"))
        out->uptime_status = INV_LIMIT;
    else {
        s = inv_read_text(p, b, sizeof(b));
        if (s != INV_OK) out->uptime_status = s;
        else if (!parse_proc_double(b, &out->uptime)) out->uptime_status = INV_INVALID_DATA;
        else out->uptime_status = INV_OK;
    }

    if (!inv_path(p, sizeof(p), c->paths.proc_root, "loadavg"))
        out->load_status = INV_LIMIT;
    else {
        s = inv_read_text(p, b, sizeof(b));
        if (s != INV_OK) out->load_status = s;
        else {
            const char *q = b;
            size_t i;
            for (i = 0; i < 3; i++) {
                while (*q == ' ' || *q == '\t') q++;
                if (!parse_proc_double(q, &out->load[i])) { out->load_status = INV_INVALID_DATA; return INV_OK; }
                while (*q && *q != ' ' && *q != '\t') q++;
        }
            out->load_status = INV_OK;
        }
    }
    return INV_OK;
}

void hal_os_cleanup(os_data *d) { (void)d; }