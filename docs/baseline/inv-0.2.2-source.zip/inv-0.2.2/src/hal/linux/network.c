// hal/linux/network.c
#include "internal.h"
#include "network.h"
#include <ctype.h>
#include <dirent.h>

static int add_row(net_data *out, const net_row *row) {
    if (out->count == out->cap) {
        size_t cap = out->cap ? out->cap * 2 : 16;
        net_row *p = (net_row *)realloc(out->rows, cap * sizeof(*p));
        if (!p) return 0;
        out->rows = p;
        out->cap = cap;
    }
    out->rows[out->count++] = *row;
    return 1;
}

/* Строка "  eth0: 16 чисел"; заполняет счётчики строки, если имя совпало. */
static inv_status apply_dev_line(const char *line, net_data *out) {
    const char *p = line;
    uint64_t vals[16];
    size_t i, k;
    while (*p == ' ' || *p == '\t') p++;
    for (i = 0; i < out->count; i++) {
        size_t n = strlen(out->rows[i].name);
        if (!strncmp(p, out->rows[i].name, n) && p[n] == ':') break;
    }
    if (i == out->count) return INV_OK; /* интерфейс без счётчиков — не ошибка */
    p = strchr(p, ':');
    if (!p) return INV_INVALID_DATA;
    p++;
    for (k = 0; k < 16; k++) {
        while (*p == ' ' || *p == '\t') p++;
        if (!isdigit((unsigned char)*p)) return INV_INVALID_DATA;
        vals[k] = 0;
        while (isdigit((unsigned char)*p)) {
            if (vals[k] > (UINT64_MAX - (uint64_t)(*p - '0')) / 10) return INV_INVALID_DATA;
            vals[k] = vals[k] * 10 + (uint64_t)(*p - '0');
            p++;
        }
    }
    out->rows[i].rx_bytes = vals[0];
    out->rows[i].rx_packets = vals[1];
    out->rows[i].rx_errors = vals[2];
    out->rows[i].rx_dropped = vals[3];
    out->rows[i].tx_bytes = vals[8];
    out->rows[i].tx_packets = vals[9];
    out->rows[i].tx_errors = vals[10];
    out->rows[i].tx_dropped = vals[11];
    return INV_OK;
}

inv_status hal_network_refresh(net_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    char root[INV_PATH_CAP], base[INV_PATH_CAP], path[INV_PATH_CAP];
    char b[INV_TEXT_CAP], dev[65536];
    DIR *dir;
    struct dirent *de;
    inv_status s;
    const char *line;

    out->count = 0;
    out->status = INV_OK;
    if (!inv_path(root, sizeof(root), c->paths.sys_root, "class/net")) {
        out->status = INV_LIMIT;
        return INV_LIMIT;
    }
    dir = opendir(root);
    if (!dir) {
        out->status = inv_errno_status(errno);
        return out->status;
    }
    while ((de = readdir(dir)) != NULL) {
        net_row row;
        if (de->d_name[0] == '.') continue;
        memset(&row, 0, sizeof(row));
        if (!inv_path(base, sizeof(base), root, de->d_name)) { s = INV_LIMIT; goto fail; }
        inv_copy(row.name, sizeof(row.name), de->d_name);
        inv_trim(row.name);
        row.speed_status = INV_OK;
        row.up_status = INV_OK;
        if (inv_path(path, sizeof(path), base, "speed")) {
            s = inv_read_text(path, b, sizeof(b));
            if (s != INV_OK) row.speed_status = s;
            else {
                int64_t x;
                if (!inv_parse_s64(b, &x)) row.speed_status = INV_INVALID_DATA;
                else if (x < 0) row.speed_status = INV_NO_DATA; /* линк есть, скорость неизвестна */
                else row.speed_mbit = (uint64_t)x;
            }
        } else { s = INV_LIMIT; goto fail; }
        if (inv_path(path, sizeof(path), base, "operstate")) {
            s = inv_read_text(path, b, sizeof(b));
            if (s != INV_OK) row.up_status = s;
            else {
                inv_trim(b);
                row.up = !strcmp(b, "up");
            }
        } else { s = INV_LIMIT; goto fail; }
        if (!add_row(out, &row)) { s = INV_NO_MEMORY; goto fail; }
    }
    closedir(dir);

    if (!inv_path(path, sizeof(path), c->paths.proc_root, "net/dev")) {
        out->status = INV_LIMIT;
        return INV_LIMIT;
    }
    s = inv_read_text(path, dev, sizeof(dev));
    if (s != INV_OK) { out->status = s; return s; }
    line = dev;
    while (*line) {
        const char *nl = strchr(line, '\n');
        size_t len = nl ? (size_t)(nl - line) : strlen(line);
        char one[1024];
        if (len < sizeof(one)) {
            memcpy(one, line, len);
            one[len] = 0;
            if (strchr(one, ':')) {
                s = apply_dev_line(one, out);
                if (s != INV_OK) { out->status = s; return s; }
            }
        }
        if (!nl) break;
        line = nl + 1;
    }
    return INV_OK;

fail:
    closedir(dir);
    out->status = s;
    return s;
}

void hal_network_cleanup(net_data *d) {
    free(d->rows);
    d->rows = NULL;
    d->count = d->cap = 0;
}