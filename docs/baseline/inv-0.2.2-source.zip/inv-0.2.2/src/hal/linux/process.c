#include "internal.h"
#include "process.h"
#include <ctype.h>
#include <dirent.h>

inv_status hal_process_refresh(process_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    char root[INV_PATH_CAP];
    DIR *dir;
    struct dirent *de;
    uint64_t count = 0;
    if (!inv_path(root, sizeof(root), c->paths.proc_root, ".")) {
        out->status = INV_LIMIT;
        return INV_LIMIT;
    }
    dir = opendir(root);
    if (!dir) {
        out->status = inv_errno_status(errno);
        return out->status;
    }
    while ((de = readdir(dir)) != NULL) {
        const char *p = de->d_name;
        if (!isdigit((unsigned char)*p)) continue;
        while (isdigit((unsigned char)*p)) p++;
        if (!*p) count++;
    }
    closedir(dir);
    out->count = count;
    out->status = INV_OK;
    return INV_OK;
}

void hal_process_cleanup(process_data *d) { (void)d; }