// hal/linux/hwmon.c
#include "internal.h"
#include "hwmon.h"
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>

inv_status hal_hwmon_open(hwmon_data *out, void *ctx) {
    (void)ctx;
    out->status = INV_OK;
    return INV_OK;
}

static int add_channel(hwmon_data *out, const hwmon_channel *ch) {
    if (out->count == out->cap) {
        size_t cap = out->cap ? out->cap * 2 : 16;
        hwmon_channel *p;
        if (cap > INV_MAX_CHANNELS) return 0;
        p = (hwmon_channel *)realloc(out->ch, cap * sizeof(*p));
        if (!p) return 0;
        out->ch = p;
        out->cap = cap;
    }
    out->ch[out->count++] = *ch;
    return 1;
}

inv_status hal_hwmon_discover(hwmon_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    char root[INV_PATH_CAP], path[INV_PATH_CAP], base[INV_PATH_CAP];
    char chip[INV_TEXT_CAP], real[PATH_MAX];
    DIR *dir, *channels;
    struct dirent *de, *chd;
    inv_status result = INV_OK, incomplete = INV_OK;
    out->count = 0;
    out->status = INV_OK;
    if (!inv_path(root, sizeof(root), c->paths.sys_root, "class/hwmon")) return INV_LIMIT;
    dir = opendir(root);
    if (!dir) return inv_errno_status(errno);
    while ((de = readdir(dir)) != NULL) {
        struct stat ds;
        uint64_t interval_ms = 0;
        if (strncmp(de->d_name, "hwmon", 5)) continue;
        if (!inv_path(base, sizeof(base), root, de->d_name) ||
            !inv_path(path, sizeof(path), base, "name")) { result = INV_LIMIT; break; }
        if (inv_read_text(path, chip, sizeof(chip)) != INV_OK) inv_copy(chip, sizeof(chip), de->d_name);
        inv_trim(chip);
        if (!realpath(base, real) || stat(base, &ds)) { incomplete = inv_errno_status(errno); continue; }
        inv_path(path, sizeof(path), base, "update_interval");
        if (inv_read_u64(path, &interval_ms) != INV_OK || interval_ms > 604800000) interval_ms = 0;
        channels = opendir(base);
        if (!channels) { incomplete = inv_errno_status(errno); continue; }
        while ((chd = readdir(channels)) != NULL) {
            hwmon_channel chan;
            char label[INV_TEXT_CAP], attr[80];
            const char *num;
            size_t plen;
            if (!strncmp(chd->d_name, "temp", 4)) { plen = 4; chan.kind = HWMON_TEMP; chan.unit = HWMON_MILLI_C; }
            else if (!strncmp(chd->d_name, "fan", 3)) { plen = 3; chan.kind = HWMON_FAN; chan.unit = HWMON_RPM; }
            else continue;
            num = chd->d_name + plen;
            if (!isdigit((unsigned char)*num)) continue;
            while (isdigit((unsigned char)*num)) num++;
            if (strcmp(num, "_input")) continue;
            if ((size_t)(num - chd->d_name) >= sizeof(chan.channel)) { result = INV_LIMIT; break; }
            memset(&chan, 0, sizeof(chan));
            if (!strncmp(chd->d_name, "temp", 4)) { chan.kind = HWMON_TEMP; chan.unit = HWMON_MILLI_C; }
            else { chan.kind = HWMON_FAN; chan.unit = HWMON_RPM; }
            memcpy(chan.channel, chd->d_name, (size_t)(num - chd->d_name));
            chan.channel[num - chd->d_name] = 0;
            inv_copy(chan.chip, sizeof(chan.chip), chip);
            snprintf(attr, sizeof(attr), "%s_label", chan.channel);
            inv_path(path, sizeof(path), base, attr);
            if (inv_read_text(path, label, sizeof(label)) != INV_OK) inv_copy(label, sizeof(label), chan.channel);
            inv_trim(label);
            inv_copy(chan.label, sizeof(chan.label), label);
            inv_copy(chan.device, sizeof(chan.device), real);
            chan.min_poll_ns = interval_ms * INV_NS_MS;
            if (snprintf(chan.entity_key, sizeof(chan.entity_key), "%s:%" PRIuMAX ":%s",
                         real, (uintmax_t)ds.st_ino, chan.channel) >= (int)sizeof(chan.entity_key) ||
                !inv_path(chan.resource, sizeof(chan.resource), base, chd->d_name)) { result = INV_LIMIT; break; }
            if (!add_channel(out, &chan)) { result = INV_NO_MEMORY; break; }
        }
        closedir(channels);
        if (result != INV_OK) break;
    }
    closedir(dir);
    out->status = result == INV_OK ? incomplete : result;
    return out->status;
}

inv_status hal_hwmon_refresh(hwmon_data *out, void *ctx) {
    (void)out; (void)ctx;
    return INV_OK; /* Linux reads each channel per sample; no group snapshot. */
}

inv_status hal_hwmon_read(const hwmon_data *d, const hwmon_channel *ch,
                          double *raw, inv_status *fault) {
    char b[128], fp[INV_PATH_CAP];
    char *end;
    uint64_t f;
    int64_t x;
    inv_status s;
    (void)d;
    *fault = INV_OK;
    inv_copy(fp, sizeof(fp), ch->resource);
    end = strrchr(fp, '_');
    if (end) inv_copy(end, sizeof(fp) - (size_t)(end - fp), "_fault");
    s = inv_read_u64(fp, &f);
    if (s == INV_OK && f) { *fault = INV_NO_DATA; return INV_OK; }
    if (s != INV_OK && s != INV_NOT_PRESENT) return s;
    s = inv_read_text(ch->resource, b, sizeof(b));
    if (s != INV_OK) return s;
    if (!inv_parse_s64(b, &x)) return INV_INVALID_DATA;
    *raw = (double)x;
    return INV_OK;
}

void hal_hwmon_cleanup(hwmon_data *d) {
    free(d->ch);
    d->ch = NULL;
    d->count = d->cap = 0;
}