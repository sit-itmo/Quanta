// hal/linux/cpuid.c
#include "internal.h"
#include "hal_cpuid.h"
#include "affinity.h"
#if INV_WITH_CPUID && INV_ARCH_X86
#include <cpuid.h>

inv_status hal_cpuid_probe(cpuid_data *out, void *ctx) {
    platform_affinity_ctx pin;
    unsigned a, b, c, d, i;
    (void)ctx;
    memset(out, 0, sizeof(*out));
    out->status = INV_UNSUPPORTED;
    if (platform_pin_thread(&pin)) { out->status = inv_errno_status(errno); return INV_OK; }
    out->ref = pin.pinned_cpu;
    if (__get_cpuid(0, &a, &b, &c, &d)) {
        memcpy(out->vendor, &b, 4);
        memcpy(out->vendor + 4, &d, 4);
        memcpy(out->vendor + 8, &c, 4);
        out->status = INV_OK;
        if (__get_cpuid(1, &a, &b, &c, &d)) { out->ecx1 = c; out->edx1 = d; }
        if (__get_cpuid_count(7, 0, &a, &b, &c, &d)) out->ebx7 = b;
        if (__get_cpuid(0x80000001u, &a, &b, &c, &d)) out->ecxext = c;
        if (__get_cpuid_max(0x80000000u, NULL) >= 0x80000004u) {
            for (i = 0; i < 3; i++) {
                __get_cpuid(0x80000002u + i, &a, &b, &c, &d);
                memcpy(out->brand + i * 16, &a, 4);
                memcpy(out->brand + i * 16 + 4, &b, 4);
                memcpy(out->brand + i * 16 + 8, &c, 4);
                memcpy(out->brand + i * 16 + 12, &d, 4);
            }
            inv_trim(out->brand);
        }
    }
    platform_restore_thread(&pin);
    return INV_OK;
}

void hal_cpuid_cleanup(cpuid_data *d) { (void)d; }
#endif /* INV_WITH_CPUID && INV_ARCH_X86 */