#include "internal.h"
#include "filesystem.h"
#include <sys/statvfs.h>

inv_status hal_fs_refresh(fs_data *out, void *ctx) {
    struct statvfs st;
    uint64_t size;
    (void)ctx; /* statvfs — системный вызов, paths не участвуют */
    if (statvfs("/", &st)) { out->status = inv_errno_status(errno); return INV_OK; }
    size = (uint64_t)(st.f_frsize ? st.f_frsize : st.f_bsize);
    if (!size || (uint64_t)st.f_blocks > UINT64_MAX / size ||
        (uint64_t)st.f_bavail > (uint64_t)st.f_blocks ||
        (uint64_t)st.f_bfree > (uint64_t)st.f_blocks) {
        out->status = INV_INVALID_DATA;
        return INV_OK;
    }
    out->total     = (uint64_t)st.f_blocks * size;
    out->free      = (uint64_t)st.f_bfree  * size;
    out->available = (uint64_t)st.f_bavail * size;
    out->status    = INV_OK;
    return INV_OK;
}

void hal_fs_cleanup(fs_data *d) { (void)d; }