// hal/windows/dmi.c
#include "windows_internal.h"
#include "dmi.h"

inv_status hal_dmi_refresh(dmi_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    UINT size = 0, got = 0;
    unsigned retry;
    const DWORD signature = UINT32_C(0x52534d42); /* 'RSMB' */
    uint8_t *bytes = NULL;

    (void)c;
    out->status = INV_NO_DATA;
    memset(&out->table, 0, sizeof(out->table));

    for (retry = 0; retry < 3; retry++) {
        size = GetSystemFirmwareTable(signature, 0, NULL, 0);
        if (!size) {
            DWORD err = GetLastError();
            out->status = err ? inv_win_status(err) : INV_NO_DATA;
            break;
        }
        if (size > 16u * 1024u * 1024u) {
            out->status = INV_LIMIT;
            break;
        }
        bytes = (uint8_t *)malloc(size);
        if (!bytes) {
            out->status = INV_NO_MEMORY;
            break;
        }
        got = GetSystemFirmwareTable(signature, 0, bytes, size);
        if (!got) {
            out->status = inv_win_status(GetLastError());
            if (out->status == INV_OK) out->status = INV_NO_DATA;
        } else if (got <= size) {
            out->status = inv_smbios_parse_windows(bytes, got, &out->table);
        }
        free(bytes); bytes = NULL;
        if (got <= size) break;
        out->status = INV_LIMIT;
    }
    return INV_OK;
}

void hal_dmi_cleanup(dmi_data *d) {
    (void)d;
}