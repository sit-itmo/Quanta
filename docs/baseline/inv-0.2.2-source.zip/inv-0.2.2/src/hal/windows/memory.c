// hal/windows/memory.c
#include "windows_internal.h"
#include "memory.h"
#include "windows_math.h"
#include <psapi.h>

inv_status hal_memory_refresh(mem_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    MEMORYSTATUSEX memory;
    PERFORMANCE_INFORMATION performance;
    memset(&memory, 0, sizeof(memory)); memory.dwLength = sizeof(memory);
    memset(&performance, 0, sizeof(performance)); performance.cb = sizeof(performance);

    out->found = 0;
    if (!GlobalMemoryStatusEx(&memory)) {
        DWORD error = GetLastError();
        inv_win_error(c, error, "GlobalMemoryStatusEx");
        out->memory_status = inv_win_status(error);
    } else {
        out->memory_status = INV_OK;
        out->total = memory.ullTotalPhys;
        out->available = memory.ullAvailPhys;
        out->found |= 3u;
    }

    if (!GetPerformanceInfo(&performance, sizeof(performance))) {
        DWORD error = GetLastError();
        inv_win_error(c, error, "GetPerformanceInfo");
        out->performance_status = inv_win_status(error);
    } else {
        out->performance_status = INV_OK;
        out->process_count = performance.ProcessCount;
        out->thread_count = performance.ThreadCount;
        out->handle_count = performance.HandleCount;
        /* Страницы -> байты один раз за кадр; переполнение = источник неиспользуем. */
        if (inv_win_pages_bytes(performance.CommitTotal, performance.PageSize, &out->commit_used) != INV_OK ||
            inv_win_pages_bytes(performance.CommitLimit, performance.PageSize, &out->commit_limit) != INV_OK ||
            inv_win_pages_bytes(performance.CommitPeak, performance.PageSize, &out->commit_peak) != INV_OK ||
            inv_win_pages_bytes(performance.SystemCache, performance.PageSize, &out->cache) != INV_OK ||
            inv_win_pages_bytes(performance.KernelPaged, performance.PageSize, &out->kernel_paged) != INV_OK ||
            inv_win_pages_bytes(performance.KernelNonpaged, performance.PageSize, &out->kernel_nonpaged) != INV_OK)
            out->performance_status = INV_INVALID_DATA;
    }
    return INV_OK; /* отказы независимых источников остаются per-field, не групповыми */
}

void hal_memory_cleanup(mem_data *d) { (void)d; }