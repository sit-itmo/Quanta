#include "windows_internal.h"
#include "process.h"
#include "memory.h"

inv_status hal_process_refresh(process_data *out, void *ctx) {
    mem_data m;
    inv_status s = hal_memory_refresh(&m, ctx);
    if (s != INV_OK) {
        out->status = s;
        return INV_OK;
    }
    if (m.performance_status != INV_OK) {
        out->status = m.performance_status;
        return INV_OK;
    }
    out->count = m.process_count;
    out->status = INV_OK;
    return INV_OK;
}

void hal_process_cleanup(process_data *d) { (void)d; }