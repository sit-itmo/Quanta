#include "windows_internal.h"
#include "filesystem.h"

inv_status hal_fs_refresh(fs_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    wchar_t root[4];
    ULARGE_INTEGER total, available;
    if (!inv_win_system_drive(root, INV_ARRAY_SIZE(root))) { out->status = INV_UNSUPPORTED; return INV_OK; }
    if (!GetDiskFreeSpaceExW(root, &available, &total, NULL)) {
        DWORD error = GetLastError();
        inv_win_error(c, error, "GetDiskFreeSpaceExW");
        out->status = inv_win_status(error);
        return INV_OK;
    }
    out->total     = total.QuadPart;
    out->available = available.QuadPart;
    out->free      = available.QuadPart; /* контракт Windows: used = total - available */
    out->status    = out->total && out->available <= out->total ? INV_OK : INV_INVALID_DATA;
    return INV_OK;
}

void hal_fs_cleanup(fs_data *d) { (void)d; }