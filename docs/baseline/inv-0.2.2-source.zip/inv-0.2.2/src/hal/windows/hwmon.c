// hal/windows/hwmon.c
#include "windows_internal.h"
#include "hwmon.h"
#include "pdh_set.h"

typedef struct win_hwmon_ctx { inv_pdh_set pdh; inv_status status; } win_hwmon_ctx;

static int add_channel(hwmon_data *out, const hwmon_channel *ch) {
    if (out->count == out->cap) {
        size_t cap = out->cap ? out->cap * 2 : 16;
        hwmon_channel *p;
        if (cap > INV_MAX_CHANNELS) return 0;
        p = (hwmon_channel *)realloc(out->ch, cap * sizeof(*p));
        if (!p) return 0;
        out->ch = p;
        out->cap = cap;
    }
    out->ch[out->count++] = *ch;
    return 1;
}

inv_status hal_hwmon_open(hwmon_data *out, void *ctx) {
    win_hwmon_ctx *win;
    (void)ctx;
    win = (win_hwmon_ctx *)calloc(1, sizeof(*win));
    if (!win) return INV_NO_MEMORY;
    out->hal_private = win;
    win->status = inv_pdh_open(&win->pdh, L"\\Thermal Zone Information(*)\\Temperature", 0);
    out->status = INV_OK;
    return INV_OK;
}

inv_status hal_hwmon_discover(hwmon_data *out, void *ctx) {
    win_hwmon_ctx *win = (win_hwmon_ctx *)out->hal_private;
    size_t i;
    (void)ctx;
    out->count = 0;
    if (win->status != INV_OK) return win->status;
    if (win->pdh.query) {
        win->status = inv_pdh_discover(&win->pdh);
        if (win->status != INV_OK) return win->status;
    }
    for (i = 0; i < win->pdh.count; i++) {
        hwmon_channel chan;
        const char *name = win->pdh.items[i].name;
        if (!strcmp(name, "_Total")) continue;
        memset(&chan, 0, sizeof(chan));
        chan.kind = HWMON_TEMP;
        chan.unit = HWMON_KELVIN;
        inv_copy(chan.chip, sizeof(chan.chip), "acpi_thermal_zone");
        inv_copy(chan.channel, sizeof(chan.channel), "temperature");
        inv_copy(chan.label, sizeof(chan.label), name);
        inv_copy(chan.device, sizeof(chan.device), name);
        inv_copy(chan.resource, sizeof(chan.resource), name);
        if (snprintf(chan.entity_key, sizeof(chan.entity_key), "thermal:%s", name) >= (int)sizeof(chan.entity_key)) return INV_LIMIT;
        chan.min_poll_ns = INV_NS_S;
        if (!add_channel(out, &chan)) return INV_NO_MEMORY;
    }
    out->status = INV_OK;
    return INV_OK;
}

inv_status hal_hwmon_refresh(hwmon_data *out, void *ctx) {
    win_hwmon_ctx *win = (win_hwmon_ctx *)out->hal_private;
    (void)ctx;
    if (win->pdh.query) return inv_pdh_collect(&win->pdh);
    return win->status;
}

inv_status hal_hwmon_read(const hwmon_data *d, const hwmon_channel *ch,
                          double *raw, inv_status *fault) {
    const win_hwmon_ctx *win = (const win_hwmon_ctx *)d->hal_private;
    const inv_pdh_item *item;
    *fault = INV_OK;
    item = inv_pdh_find(&win->pdh, ch->resource);
    if (!item) return INV_GONE;
    if (item->status != INV_OK) return item->status;
    *raw = item->value;
    return INV_OK;
}

void hal_hwmon_cleanup(hwmon_data *d) {
    win_hwmon_ctx *win = (win_hwmon_ctx *)d->hal_private;
    if (win) {
        inv_pdh_close(&win->pdh);
        free(win);
        d->hal_private = NULL;
    }
    free(d->ch);
    d->ch = NULL;
    d->count = d->cap = 0;
}