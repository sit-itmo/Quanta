#include "windows_internal.h"
#include "os.h"

inv_status hal_os_refresh(os_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    WCHAR wbuf[256];
    DWORD len = INV_ARRAY_SIZE(wbuf);
    RTL_OSVERSIONINFOW ver;
    (void)ctx;
    memset(out, 0, sizeof(*out));

    if (!GetComputerNameExW(ComputerNameDnsHostname, wbuf, &len)) {
        DWORD err = GetLastError();
        inv_win_error(c, err, "GetComputerNameExW");
        out->hostname_status = inv_win_status(err);
    } else {
        WideCharToMultiByte(CP_UTF8, 0, wbuf, -1, out->hostname, sizeof(out->hostname), NULL, NULL);
        out->hostname_status = INV_OK;
    }

    ver.dwOSVersionInfoSize = sizeof(ver);
    if (RtlGetVersion(&ver) == 0) {
        snprintf(out->kernel, sizeof(out->kernel), "%lu.%lu.%lu",
                 ver.dwMajorVersion, ver.dwMinorVersion, ver.dwBuildNumber);
        snprintf(out->name, sizeof(out->name), "Windows");
        snprintf(out->version, sizeof(out->version), "%lu.%lu",
                 ver.dwMajorVersion, ver.dwMinorVersion);
        out->kernel_status = INV_OK;
    } else {
        out->kernel_status = INV_UNSUPPORTED;
    }

    out->uptime = (double)GetTickCount64() / 1000.0;
    out->uptime_status = INV_OK;
    out->load_status = INV_UNSUPPORTED;
    return INV_OK;
}

void hal_os_cleanup(os_data *d) { (void)d; }