// hal/windows/cpuid.c
#include "windows_internal.h"
#include "hal_cpuid.h"
#include "affinity.h"
#if INV_WITH_CPUID && INV_ARCH_X86
#include <intrin.h>

inv_status hal_cpuid_probe(cpuid_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    platform_affinity_ctx pin;
    int r[4];
    unsigned max, emax, i;
    memset(out, 0, sizeof(*out));
    out->status = INV_UNSUPPORTED;
    if (platform_pin_thread(&pin)) {
        DWORD err = GetLastError();
        if (c) inv_win_error(c, err, "SetThreadGroupAffinity");
        out->status = err ? inv_win_status(err) : INV_UNSUPPORTED;
        return INV_OK;
    }
    out->ref = pin.pinned_cpu; /* (group << 16) | processor_number, как в доках */
    __cpuidex(r, 0, 0);
    max = (unsigned)r[0];
    if (max) {
        memcpy(out->vendor, &r[1], 4);
        memcpy(out->vendor + 4, &r[3], 4);
        memcpy(out->vendor + 8, &r[2], 4);
        out->status = INV_OK;
        if (max >= 1) { __cpuidex(r, 1, 0); out->ecx1 = (uint32_t)r[2]; out->edx1 = (uint32_t)r[3]; }
        if (max >= 7) { __cpuidex(r, 7, 0); out->ebx7 = (uint32_t)r[1]; }
    }
    __cpuidex(r, 0x80000000u, 0);
    emax = (unsigned)r[0];
    if (emax >= 0x80000001u) { __cpuidex(r, 0x80000001u, 0); out->ecxext = (uint32_t)r[2]; }
    if (emax >= 0x80000004u) {
        for (i = 0; i < 3; i++) {
            __cpuidex(r, (int)(0x80000002u + i), 0);
            memcpy(out->brand + i * 16, &r[0], 4);
            memcpy(out->brand + i * 16 + 4, &r[1], 4);
            memcpy(out->brand + i * 16 + 8, &r[2], 4);
            memcpy(out->brand + i * 16 + 12, &r[3], 4);
        }
        inv_trim(out->brand);
    }
    platform_restore_thread(&pin);
    return INV_OK;
}

void hal_cpuid_cleanup(cpuid_data *d) { (void)d; }
#endif /* INV_WITH_CPUID && INV_ARCH_X86 */