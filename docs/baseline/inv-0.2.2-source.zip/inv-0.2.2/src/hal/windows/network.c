// hal/windows/network.c
#include "windows_internal.h"
#include "network.h"
#include <iphlpapi.h>

static void wide_to_utf8(char *dst, size_t cap, const WCHAR *src) {
    if (!cap) return;
    dst[0] = 0;
    if (WideCharToMultiByte(CP_UTF8, 0, src, -1, dst, (int)cap, NULL, NULL) <= 0) dst[0] = 0;
}

static int add_row(net_data *out, const net_row *row) {
    if (out->count == out->cap) {
        size_t cap = out->cap ? out->cap * 2 : 16;
        net_row *p = (net_row *)realloc(out->rows, cap * sizeof(*p));
        if (!p) return 0;
        out->rows = p;
        out->cap = cap;
    }
    out->rows[out->count++] = *row;
    return 1;
}

inv_status hal_network_refresh(net_data *out, void *ctx) {
    MIB_IF_TABLE2 *table = NULL;
    DWORD error;
    ULONG i;
    (void)ctx;
    out->count = 0;
    out->status = INV_OK;
    error = GetIfTable2(&table);
    if (error != NO_ERROR) {
        out->status = inv_win_status(error);
        return INV_OK; /* per-source статус, как принято на Windows */
    }
    for (i = 0; i < table->NumEntries; i++) {
        const MIB_IF_ROW2 *r = &table->Table[i];
        uint64_t bps;
        net_row row;
        memset(&row, 0, sizeof(row));
        wide_to_utf8(row.name, sizeof(row.name), r->Alias);
        if (!row.name[0]) wide_to_utf8(row.name, sizeof(row.name), r->Description);
        if (!row.name[0]) continue; /* нет идентичности — нет серии */
        wide_to_utf8(row.device, sizeof(row.device), r->Description);
        if (!row.device[0]) inv_copy(row.device, sizeof(row.device), row.name);
        row.rx_bytes = r->CounterData.InOctets;
        row.rx_packets = r->CounterData.InUcastPkts;
        row.rx_errors = r->CounterData.InErrors;
        row.rx_dropped = r->CounterData.InDiscards;
        row.tx_bytes = r->CounterData.OutOctets;
        row.tx_packets = r->CounterData.OutUcastPkts;
        row.tx_errors = r->CounterData.OutErrors;
        row.tx_dropped = r->CounterData.OutDiscards;
        bps = r->ReceiveLinkSpeed > r->TransmitLinkSpeed ? r->ReceiveLinkSpeed : r->TransmitLinkSpeed;
        row.speed_mbit = bps / 1000000u;
        row.speed_status = INV_OK;
        row.up = (r->OperStatus == IfOperStatusUp);
        row.up_status = INV_OK;
        if (!add_row(out, &row)) {
            FreeMibTable(table);
            out->status = INV_NO_MEMORY;
            return INV_OK;
        }
    }
    FreeMibTable(table);
    return INV_OK;
}

void hal_network_cleanup(net_data *d) {
    free(d->rows);
    d->rows = NULL;
    d->count = d->cap = 0;
}