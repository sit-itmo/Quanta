// hal/windows/cpu.c
#include "cpu.h"
#include "windows_internal.h"
#include "pdh_set.h"

typedef struct win_cpu_ctx {
    inv_pdh_set pdh;
    int pdh_active;
    inv_status pdh_status;
} win_cpu_ctx;

static void add_row(cpu_data *out, const char *name, uint64_t user, uint64_t nice, 
                    uint64_t system, uint64_t idle, uint64_t iowait) {
    if (out->count == out->cap) {
        size_t cap = out->cap ? out->cap * 2 : 64;
        cpu_row *r = realloc(out->rows, cap * sizeof(*r));
        if (!r) return;
        out->rows = r;
        out->cap = cap;
    }
    cpu_row *row = &out->rows[out->count++];
    memset(row, 0, sizeof(*row));
    inv_copy(row->name, sizeof(row->name), name);
    row->t[CPU_USER] = user; row->t[CPU_NICE] = nice; row->t[CPU_SYSTEM] = system; 
    row->t[CPU_IDLE] = idle; row->t[CPU_IOWAIT] = iowait;
}

inv_status hal_cpu_refresh(cpu_data *out, void *ctx) {
    inv_read_ctx *c = (inv_read_ctx *)ctx;
    win_cpu_ctx *win = (win_cpu_ctx *)out->hal_private;
    
    if (!win) {
        win = calloc(1, sizeof(win_cpu_ctx));
        out->hal_private = win;
    }

    out->count = 0;
    out->tick_frequency_hz = 10000000; // 100нс тики в Windows

    // 1. Агрегат через GetSystemTimes
    FILETIME idle, kernel, user;
    if (GetSystemTimes(&idle, &kernel, &user)) {
        uint64_t u = inv_win_filetime(user);
        uint64_t k = inv_win_filetime(kernel);
        uint64_t i = inv_win_filetime(idle);
        
        // В Windows kernel time включает idle. 
        // Чтобы сумма t[0]+t[2]+t[3] равнялась u+k, делаем system = k - i.
        add_row(out, "cpu", u, 0, (k > i ? k - i : 0), i, 0);
    }

    // 2. Ядра через PDH (если нужно)
    // Инициализируем PDH, если ещё не открыт
    if (!win->pdh_active) {
        win->pdh_status = inv_pdh_open(&win->pdh, L"\\Processor Information(*)\\% Processor Time", 1);
        if (win->pdh_status == INV_OK) win->pdh_active = 1;
    }

    if (win->pdh_active && win->pdh.query) {
        inv_pdh_discover(&win->pdh);
        inv_pdh_collect(&win->pdh);

        for (size_t j = 0; j < win->pdh.count; j++) {
            const inv_pdh_item *item = &win->pdh.items[j];
            if (item->status != INV_OK || !strcmp(item->name, "_Total")) continue;

            unsigned group = 0, number = 0;
            if (inv_win_cpu_instance(item->name, &group, &number) != 1) continue;

            // Синтезируем тики из процента (0.0 .. 1.0)
            double val = item->value / 100.0;
            if (val < 0) val = 0; if (val > 1) val = 1;
            
            uint64_t busy_ticks = (uint64_t)(val * 10000);
            uint64_t idle_ticks = 10000 - busy_ticks;

            char core_name[24];
            snprintf(core_name, sizeof(core_name), "cpu%u", number); // Унифицируем имена
            
            add_row(out, core_name, busy_ticks, 0, 0, idle_ticks, 0);
        }
    }

    out->time_ns = inv_now_ns();
    return INV_OK;
}

void hal_cpu_cleanup(cpu_data *d) {
    win_cpu_ctx *win = (win_cpu_ctx *)d->hal_private;
    if (win) {
        if (win->pdh_active) inv_pdh_close(&win->pdh);
        free(win);
        d->hal_private = NULL;
    }
    free(d->rows);
    d->rows = NULL;
    d->count = d->cap = 0;
}