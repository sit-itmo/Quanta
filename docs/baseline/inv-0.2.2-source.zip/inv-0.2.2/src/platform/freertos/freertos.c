/* SPDX-License-Identifier: MIT */
#include "internal.h"
#include <FreeRTOS.h>
#include <task.h>

static volatile int interrupted;
/* 64-битное монотонное время из 32-битного счётчика тиков с аккумуляцией wrap.
 * Одно ядро => критическая секция достаточна. Требуется configTICK_RATE_HZ >= 100. */
static uint64_t tick_acc;
static uint32_t tick_last;

uint64_t inv_now_ns(void) {
    uint32_t now = xTaskGetTickCount();
    uint64_t ticks;
    taskENTER_CRITICAL();
    if (now < tick_last) tick_acc += (uint64_t)UINT32_MAX + 1;
    tick_last = now;
    ticks = tick_acc + now;
    taskEXIT_CRITICAL();
    return ticks * (INV_NS_S / configTICK_RATE_HZ);
}

uint64_t inv_realtime_ns(void) {
    return 0; /* настенных часов без RTC/SNTP нет; этап 1 печатает 1970, это ожидаемо */
}

void inv_sleep_ns(uint64_t ns) {
    while (ns && !inv_interrupted()) {
        uint32_t ms = (uint32_t)(ns / INV_NS_MS);
        uint64_t start, elapsed;
        if (!ms) ms = 1;
        if (ms > 20) ms = 20; /* короткие чанки держат отзывчивость, как на десктопе */
        start = inv_now_ns();
        vTaskDelay(pdMS_TO_TICKS(ms));
        elapsed = inv_now_ns() - start;
        if (!elapsed || elapsed >= ns) break;
        ns -= elapsed;
    }
}

int inv_install_signal_handlers(void) { return 1; /* сигналов на MCU нет: успех-пустышка */ }
int inv_interrupted(void) { return interrupted; }
unsigned long inv_process_id(void) { return 1; }

int inv_path(char *out, size_t cap, const char *root, const char *rel) {
    int n = snprintf(out, cap, "%s/%s", root, rel);
    return n >= 0 && (size_t)n < cap;
}

inv_status inv_read_text(const char *path, char *out, size_t cap) {
    (void)path; (void)cap;
    if (cap) out[0] = 0;
    return INV_NOT_PRESENT; /* файловой системы нет */
}

inv_status inv_read_u64(const char *path, uint64_t *v) {
    (void)path; (void)v;
    return INV_NOT_PRESENT;
}

FILE *inv_fopen_utf8(const char *path, const char *mode) { (void)path; (void)mode; return NULL; }
FILE *inv_create_output(const char *path) { (void)path; return NULL; }