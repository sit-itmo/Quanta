/* SPDX-License-Identifier: MIT */
#include "thread.h"
#include <FreeRTOS.h>
#include <semphr.h>
#include <task.h>

int inv_mutex_init(inv_mutex *m) { *m = xSemaphoreCreateMutex(); return *m ? 0 : 1; }
void inv_mutex_destroy(inv_mutex *m) { if (*m) vSemaphoreDelete(*m); *m = NULL; }
void inv_mutex_lock(inv_mutex *m) { xSemaphoreTake(*m, portMAX_DELAY); }
void inv_mutex_unlock(inv_mutex *m) { xSemaphoreGive(*m); }

/* condvar через бинарный семафор не атомарен с mutex (wait отпускает
 * mutex отдельно). Ядро (inv_core) condvar не использует вообще — они нужны только
 * inv_live из inv_view, который на MCU не линкуется. Хватит для будущего одиночного
 * producer/consumer; полноценный condvar появится, если понадобится live-очередь. */
int inv_condition_init(inv_condition *c) { *c = xSemaphoreCreateBinary(); return *c ? 0 : 1; }
void inv_condition_destroy(inv_condition *c) { if (*c) vSemaphoreDelete(*c); *c = NULL; }
void inv_condition_wait(inv_condition *c, inv_mutex *m) {
    inv_mutex_unlock(m);
    xSemaphoreTake(*c, portMAX_DELAY);
    inv_mutex_lock(m);
}
void inv_condition_signal(inv_condition *c) { xSemaphoreGive(*c); }
void inv_condition_broadcast(inv_condition *c) { xSemaphoreGive(*c); /* single-consumer approximation */ }

typedef struct frt_start { void *(*fn)(void *); void *arg; SemaphoreHandle_t done; } frt_start;

static void entry(void *p) {
    frt_start s = *(frt_start *)p;
    vPortFree(p);
    (void)s.fn(s.arg);
    xSemaphoreGive(s.done);
    vTaskDelete(NULL);
}

int inv_thread_start(inv_thread *t, void *(*fn)(void *), void *arg) {
    frt_start *s = (frt_start *)pvPortMalloc(sizeof(*s));
    if (!s) return 1;
    s->fn = fn; s->arg = arg;
    s->done = xSemaphoreCreateBinary();
    if (!s->done) { vPortFree(s); return 1; }
    t->done = s->done;
    if (xTaskCreate(entry, "inv", 2048, s, 5, &t->handle) != pdPASS) {
        vSemaphoreDelete(s->done); vPortFree(s); return 1;
    }
    return 0;
}

void inv_thread_join(inv_thread *t) {
    if (t->done) {
        xSemaphoreTake(t->done, portMAX_DELAY);
        vSemaphoreDelete(t->done);
        t->done = NULL;
    }
}