# cpu.time_total

## Linux / исходный провайдер

CPU accounted ticks — semantic version 1.

## Contract

- Type: `u64`; kind: `counter`.
- Canonical unit: `ticks`.
- Refresh policy: `INV_REFRESH_POLL`. Descriptor minimum: 100 ms. Requested period is clamped or rejected in strict mode.
- Labels: `(none)`.
- Source: one /proc/stat snapshot, first eight CPU time fields only.

## Meaning

Sum of the first eight aggregate /proc/stat CPU fields, in kernel USER_HZ ticks. This is not nanoseconds, not CPU clock cycles, and not necessarily strictly monotonic across kernel accounting anomalies.

First utilization sample is WARMUP. A decreasing field (including iowait), no delta, or a new instance resets the baseline; impossible negative utilization is never emitted.

The procfs view may describe the host rather than this process cgroup. Container limits/quota normalization are outside v0.1.

## Errors and unavailable values

A successful zero/false/empty string is distinct from an unsuccessful read.
PERMISSION_DENIED reports access restrictions; NOT_PRESENT/GONE report missing
resources; INVALID_DATA reports malformed/range-invalid input; NO_DATA reports
missing required source fields. The last successful sample may be displayed
with its original age, never as a newly successful measurement.

## Query

```text
mode file; format table; once; select optional cpu.time_total;
```

For a derived rate or CPU utilization, allow a baseline with `--warmup 1200ms`
or run a periodic query. Actual minimums can require a longer interval.

## Reference

https://docs.kernel.org/filesystems/proc.html

## Windows (0.2)

На системе с одной процессорной группой GetSystemTimes даёт aggregate kernel + user;
idle уже входит в kernel и второй раз не добавляется. Загрузка вычисляется по двум снимкам:
1 − Δidle / Δ(kernel+user). Начальный результат и сбросы — WARMUP.
Единица сырых cpu.time_total / cpu.idle_total — 100-нс ticks; частота явно задана
windows.cpu.tick_frequency_hz = 10 000 000. Это не USER_HZ Linux.
На системах с несколькими группами сырые aggregate tick-метрики возвращают UNSUPPORTED,
а общая и поядерная загрузка используют PDH Processor Information / % Processor Time.
Метки cpu.core.utilization: cpu="group,number", group и number. Локализация PDH выполняется
через PdhAddEnglishCounterW и локализованный wildcard; имена групп не зависят от языка интерфейса.
Метрика измеряет долю занятого процессорного времени, а не Processor Utility с поправкой на частоту.

Описание API: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getsystemtimes
